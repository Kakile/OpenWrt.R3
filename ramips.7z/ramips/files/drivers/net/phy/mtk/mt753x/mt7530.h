/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (c) 2018 MediaTek Inc.
 */

#ifndef _MT7530_H_
#define _MT7530_H_

#include "mt753x.h"

extern struct mt753x_sw_id mt7530_id;

#endif /* _MT7530_H_ */
